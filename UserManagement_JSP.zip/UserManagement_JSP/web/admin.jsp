<%-- 
    Document   : admin
    Created on : Sep 21, 2026, 8:48:50 AM
    Author     : hd
--%>

<%@page import="java.util.List"%>
<%@page import="fa26.user.UserDTO"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Administrator Page</title>
    </head>
    <body>
        <%
            UserDTO loginUser = (UserDTO) session.getAttribute("LOGIN_USER");
            if (loginUser != null) {
                loginUser = new UserDTO();
            }
            String search = request.getParameter("search");
            if (search == null) {
                search = "";
            }

        %>
        <h1>Welcome: <%= loginUser.getName()%></h1>
        <form action="MainController">
            Search:<input type="text" name="search" value="<%= search%>" required=""/>
            <input type="submit" name="action" value="Search"/>
        </form>

        <%
            List<UserDTO> listUser = (List<UserDTO>) session.getAttribute("LIST_USER");
            if (listUser == null || listUser.isEmpty()) {
                String errorMessage = (String) request.getAttribute("ERROR_MESSAGE");
                if (errorMessage == null)
                    errorMessage = "";
        %>
        <h1><%= errorMessage%></h1>
        <%
        } else {
        %>
        <table border="1">
            <thead>
                <tr>
                    <th>No</th>
                    <th>UID</th>
                    <th>Name</th>
                    <th>Role ID</th>
                    <th>Password</th>
                    <th>Status</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                <%
                    int count = 1;
                    for (UserDTO user : listUser) {
                %>
                <tr>
                    <td><%= count++%></td>
                    <td><%= user.getuID()%></td>
                    <td><%= user.getName()%></td>
                    <td><%= user.getRoleID()%></td>
                    <td><%= user.getPassword()%></td>
                    <td><%= user.isStatus()%></td>
                    <td><a href="MainController?action=Delete& search=<%= search%>&uID=<%= user.getName()%>">Delete</a></td>
                </tr>
                <%
                    }
                %>

            </tbody>
        </table>
        <% String errorMessage = (String) request.getAttribute("ERROR_MESSAGE");
            if (errorMessage == null)
                errorMessage = "";
        %>

        <%= errorMessage%>
        <%
            }
        %>
    </body>
</html>
