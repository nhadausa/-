<%-- 
    Document   : user
    Created on : Sep 21, 2026, 8:45:22 AM
    Author     : hd
--%>

<%@page import="fa26.user.UserDTO"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>User Page</title>
    </head>
    <body>
        <h1>Welcome:</h1>
        <% 
            UserDTO loginUser= (UserDTO)session.getAttribute("LOGIN_USER");
            if(loginUser== null){
                loginUser= new UserDTO();
            }
        
        %>
        UID:<%= loginUser.getuID() %></br>
        Name:<%= loginUser.getName()%></br>
        RoleID:<%= loginUser.getRoleID()%></br>
        Password:****
    </body>
</html>
