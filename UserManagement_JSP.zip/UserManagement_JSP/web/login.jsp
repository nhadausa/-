<%-- 
    Document   : login
    Created on : Sep 21, 2026, 7:44:26 AM
    Author     : hd
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Login Page</title>
    </head>
    <body>
        <form action="MaiinControllers" method="POST">
            UID:<input type="text" name="uID" required=""/></br>
            Password:<input type="password" name="Password" required=""/></br>
            <input type="submit" name="Login" value="Login"/>
            <input type="reset" value="Reset" />
        </form>
        <% 
            String errorMessage= (String)request.getAttribute("ERRORMESSAGE");
            if(errorMessage== null) errorMessage="";
        %>
        <%= errorMessage %>
        
        
    </body>
</html>
