/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package fa26.controllers;

import fa26.user.UserDAO;
import fa26.user.UserDTO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author hd
 */
@WebServlet(name = "LoginController", urlPatterns = {"/LoginController"})
public class LoginController extends HttpServlet {

    public static final String ERROR="login.jsp";
    public static final String ADMIN_ROLE="AD";
    public static final String ADMIN_PAGE="admin.jsp";
    public static final String USER_ROLE="US";
    public static final String USER_PAGE="user.jsp";
    public static final String INCORRECT_MESSAGE="Incorrect uID or Password !!";
    public static final String NOT_SUPPORT_MESSAGE="Your role is not support yet !!";
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url= ERROR;
        try {
            String uID= request.getParameter("uID");
            String password= request.getParameter("password");
            UserDAO dao= new UserDAO();
            UserDTO loginUser= dao.checkLogin(uID, password);
            //xác thực ở đây nè 
            if(loginUser== null){
                request.setAttribute("ERROR_MESSAGE", INCORRECT_MESSAGE);
            }else{
//                phân quyền ở đây nè 
                HttpSession session= request.getSession();
                session.setAttribute("loginUser", loginUser);
                String roleID= loginUser.getRoleID();
                if(ADMIN_ROLE.equals(roleID)){
                    url= ADMIN_PAGE;
                }else if(USER_ROLE.equals(roleID)){
                    url= USER_PAGE;
                }else{
                    request.setAttribute("ERROR_MESSAGE", NOT_SUPPORT_MESSAGE);
                }
            }
        } catch (Exception e) {
            log("Error at LoginController: "+ e.toString());
        }finally{
            response.sendRedirect(ERROR);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
