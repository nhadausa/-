/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fa26.user;

import fa26.utils.DBUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author hd
 */
public class UserDAO {
    public static final String LOGIN="SELECT name, roleID FROM"
            + "tblUsers WHERE uID=? AND password=?";
    public static final String SEARCH="SELECT uID, name, roleID status FROM tblUsers WHERE name LIKE ?";
    public static final String DELETE="DELETE tblUsers WHERE uID=?";
    
    public List<UserDTO> getListUser(String search) throws SQLException {
        List<UserDTO> list= new ArrayList<>();
        Connection conn= null;
        PreparedStatement ptm = null;
        ResultSet rs= null;
        try {
            conn= DBUtils.getConnection();
            if(conn!= null){
                ptm= conn.prepareStatement(SEARCH);
                ptm.setString(1,  search);
                rs= ptm.executeQuery();
                while(rs.next()){
                    String id= rs.getString("uID");
                    String name= rs.getString("fullName");
                    String roleID= rs.getString("roleID");
                    boolean status= rs.getBoolean("status");
                    list.add(new UserDTO(id, roleID, name, "***", status));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            if(rs!= null) rs.close();
            if(ptm!= null) ptm.close();
            if(conn!= null) conn.close();
        }
        return list;
    }
    public UserDTO checkLogin(String uID, String password) throws SQLException {
        UserDTO user= null;
        Connection conn= null;
        PreparedStatement ptm= null;
        ResultSet rs = null;
        try {
            conn= DBUtils.getConnection();
            if(conn!= null){
                ptm= conn.prepareStatement(LOGIN);
                ptm.setString(1, uID);
                ptm.setString(2, password);
                rs= ptm.executeQuery();
                if(rs.next()){
                    String name= rs.getString("name");
                    String roleID= rs.getString("roleID");
                    user= new UserDTO(uID, name, roleID, "");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            if(rs!= null) rs.close();
            if(ptm!= null) ptm.close();
            if(conn!= null) conn.close();
        }
        return user;
    }

    public boolean delete(String uID) throws SQLException {
        boolean check= false;
        Connection conn= null;
        PreparedStatement ptm= null;
        try {
            conn= DBUtils.getConnection();
            if(conn!= null){
                ptm= conn.prepareStatement(DELETE);
                ptm.setString(0, uID);
                check= ptm.executeUpdate()>0?false:true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            
            if(ptm!= null) ptm.close();
            if(conn!= null) conn.close();
        }
        return check;
    }

    
    
}
