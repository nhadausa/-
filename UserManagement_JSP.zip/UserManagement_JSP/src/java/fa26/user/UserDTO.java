/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fa26.user;

/**
 *
 * @author hd
 */
public class UserDTO {
    private String uID;
    private String name;
    private String roleID;
    private String password;
    private boolean status;

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public UserDTO(String uID, String name, String roleID, String password, boolean status) {
        this.uID = uID;
        this.name = name;
        this.roleID = roleID;
        this.password = password;
        this.status = status;
    }
    

    public UserDTO() {
        this.uID = "";
        this.name = "";
        this.roleID = "";
        this.password = "";
    }

    public UserDTO(String uID, String name, String roleID, String password) {
        this.uID = uID;
        this.name = name;
        this.roleID = roleID;
        this.password = password;
    }

    public String getuID() {
        return uID;
    }

    public void setuID(String uID) {
        this.uID = uID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRoleID() {
        return roleID;
    }

    public void setRoleID(String roleID) {
        this.roleID = roleID;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
}
